# Shovon Mandal Academic Portfolio — V58 Final Realtime Experience Count

Final update:
- Experience segment now includes real-time duration count in years and months
- Current role duration updates automatically from March 2024 to the current month
- Previous roles show month-based academic CV duration
- Experience institute hover links and all previous approved organization fixes preserved
